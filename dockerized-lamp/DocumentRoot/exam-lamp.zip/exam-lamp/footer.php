<?php
require "config.php"
?>
<footer class="py-5 bg-dark">
    <div class="container">
        <!-- TO-DO-->
        <!-- Poner aqui tu nombre, des del fichero de configuración -->
        <p class="m-0 text-center text-white">Copyright <?php echo ($Author);?> Your Website 2020</p>
    </div>
    <!-- /.container -->
</footer>
