<?php
require "config.php"
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <!-- TO-DO: Afegir el logo, extret de la configuració -->
      <a class="navbar-brand" href="#"><img src="<?php echo ($Logo);?>"/></a>
      </div>
    </div>
  </nav>

