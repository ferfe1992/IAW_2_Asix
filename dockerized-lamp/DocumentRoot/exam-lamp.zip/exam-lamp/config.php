<?php
// Configuración del sitio
$Site="ASIX Black Friday";
$Logo="img/logo.png";
$Author="Alumne ASIX Fernando";

// Configuración de la BD de datos

$BDserver="192.168.1.21"; // IP del servidor de BD (tu IP pública)
$BDport="3308";
$BD="productos";
$user="root";
$password="rootpwd";
?>
